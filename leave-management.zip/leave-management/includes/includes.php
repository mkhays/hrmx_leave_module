<?php
require('includes/constants.php');

define('TMVC_SQL_NONE', 0);
define('TMVC_SQL_INIT', 1);
define('TMVC_SQL_ALL', 2);

?>