<?php
//database 1
define ('DB_USER', "hrm_user2");
define ('DB_PASSWORD', "123Hrm123");
define ('DB_DATABASE', "baylor_hrm");
define ('DB_HOST', "localhost");

?>