<?php
/*define('LEAVE_PTL_PATH', $_SERVER['DOCUMENT_ROOT'].'/hrm/template/');
define('TAB_TITLE','Human Resource Manager');
define('ADMIN_TITLE','Control Panel');
define('MAIN_TITLE', 'Baylor Intergrated Human Resource Information System');
define('BRAND','BIHRIS');*/

define('TMVC_SQL_NONE', 0);
define('TMVC_SQL_INIT', 1);
define('TMVC_SQL_ALL', 2);
?>