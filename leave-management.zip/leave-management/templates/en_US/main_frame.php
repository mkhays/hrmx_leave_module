 <div class="container bs-docs-container">
      <div class="row">
        <div class="col-md-2">
          <div class="bs-sidebar hidden-print" id="side2" role="complementary">
            <ul class="nav bs-sidenav nav-stacked"> 
                <?php require(SIDE_MENU); ?>           
            </ul>
          </div>
        </div>
        <div class="col-md-10" role="main">  
      <?php //require(TEMPLATE_PATH.'/view_users.php');
	//  require(CONTENT);
	  require(MAIN_CONTENT); 
	   ?>
        </div>
            <!-- Overview-->