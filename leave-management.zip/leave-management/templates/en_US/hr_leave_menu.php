
<li class="disabled"><a href="">Leave Form</a></li> 
<li class="disabled"><a href="">Out of Office Form</a></li> 
<li class="disabled"><a href=""><span class="badge pull-right"></span>Recent Activity and Feedback</a></li> 
<li><a href="index.php?request=leave_requests&link=leave"><span class="badge pull-right"><?php if($num==0){echo '';}else echo $num;  ?></span>Leave Requests</a></li>
<li class="disabled"><a href="">History</a></li>

 