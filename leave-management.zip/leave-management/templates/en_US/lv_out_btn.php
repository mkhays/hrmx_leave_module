<form class="form-horizontal" action="index.php?request=back_in_office2" method="post" role="form">
      <legend><?php  echo "Still out of Office?";   ?></legend>
<button type="submit" class="btn btn-primary">Back in office</button>
</form>