
 </div><!--/.fluid-container-->
</div><!--/.fluid-container-->
<div class="push"></div>
</div>
<footer>
    <div id="footer">
      <div class="container"> <p class="help-block"><br />
       Designed and built by <b style="color:#39F">Baylor I.T Department</b>.<br />
       BIHRIS V.1.0.</p><br />
      </div>
      </div>
      </footer>
      